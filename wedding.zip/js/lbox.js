$(document).ready(function(){
  $("a.[rel='galer']").colorbox();
});